# -*- coding: utf-8 -*-
"""
state_manager.py — Lifecycle manager for pages/<slug>.state.json sidecars.

Used by the SEO Copywriter Agent's checkpoint-gated workflow (claude.md v2.0)
to track which checkpoint a page build has reached. Every state mutation
goes through this script — never write the file by hand, never inline atomic
write logic into other scripts.

Commands:
    create <slug> <task_id>
        Initialise pages/<slug>.state.json at CP-A start.
        Idempotent re-creation is rejected — operator must abort first.

    advance <slug> <next_checkpoint> --command <op_command>
        Atomically advance the checkpoint pointer. Logs the operator command
        in operator_signoffs. Valid next_checkpoint values: CP-A..CP-E, DONE.

    record-violations <slug> <check1> [<check2> ...]
        Write a violation list into violations_at_last_validator_run without
        advancing. Used at failed CP-D.

    clear-violations <slug>
        Empty the violations list (used after a successful re-run).

    load <slug>
        Print the current state JSON. Used for `inspect` operator command
        and on `resume <slug>`. Validates hash; exits 2 on hash mismatch.

    finish <slug>
        Delete state.json. Refuses unless output/<slug>.xlsx exists on disk.
        Used at the very end of CP-E.

    abort <slug>
        Delete state.json immediately. Leaves pages/<slug>.yaml in place.

Exit codes:
    0 — success
    1 — operational error (e.g. file already exists for create)
    2 — integrity error (hash mismatch, malformed JSON)
    3 — bad arguments

Atomicity:
    Every write goes to <path>.tmp then os.replace()s onto the canonical path.
    A crash during write leaves the prior valid state intact.

Hash:
    amo_hash = sha256(canonical_json(state minus the amo_hash field itself)).
    Computed on every write, verified on every load.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
PAGES_DIR = REPO_ROOT / "pages"
OUTPUT_DIR = REPO_ROOT / "output"

VALID_CHECKPOINTS = {"CP-0", "CP-A", "CP-B", "CP-C", "CP-D", "CP-E", "DONE"}
SCHEMA_VERSION = "1.0"


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def state_path(slug: str) -> Path:
    return PAGES_DIR / f"{slug}.state.json"


def yaml_path(slug: str) -> Path:
    return PAGES_DIR / f"{slug}.yaml"


def xlsx_path(slug: str) -> Path:
    return OUTPUT_DIR / f"{slug}.xlsx"


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Hash + canonical serialization
# ---------------------------------------------------------------------------

def canonical_payload(state: dict) -> str:
    """JSON-serialize the state with sorted keys, minus the amo_hash field.
    This is the input to sha256."""
    payload = {k: v for k, v in state.items() if k != "amo_hash"}
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def compute_hash(state: dict) -> str:
    return hashlib.sha256(canonical_payload(state).encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Atomic IO
# ---------------------------------------------------------------------------

def write_state(slug: str, state: dict) -> None:
    """Atomic write: <path>.tmp then os.replace onto the canonical path."""
    state["updated_at"] = now_iso()
    state["amo_hash"] = compute_hash(state)
    canonical = state_path(slug)
    tmp = canonical.with_suffix(canonical.suffix + ".tmp")
    canonical.parent.mkdir(parents=True, exist_ok=True)
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, canonical)


def read_state(slug: str) -> dict:
    """Read state.json and validate its hash. Raises on failure."""
    path = state_path(slug)
    if not path.exists():
        raise FileNotFoundError(f"state file not found at {path}")
    with path.open("r", encoding="utf-8") as f:
        try:
            state = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"state file at {path} is malformed JSON: {e}")
    declared = state.get("amo_hash", "")
    computed = compute_hash(state)
    if declared != computed:
        raise IntegrityError(
            f"CHECKPOINT_HASH_INVALID: declared={declared[:16]}... "
            f"computed={computed[:16]}... at {path}"
        )
    return state


class IntegrityError(Exception):
    pass


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_create(slug: str, task_id: str) -> int:
    path = state_path(slug)
    if path.exists():
        print(
            f"ERROR: state file already exists at {path}. "
            f"Run `abort {slug}` first to discard, or `load {slug}` to resume.",
            file=sys.stderr,
        )
        return 1

    state = {
        "task_id": task_id,
        "page_slug": slug,
        "schema_version": SCHEMA_VERSION,
        "last_checkpoint": "CP-0",
        "next_checkpoint": "CP-A",
        "yaml_path": f"pages/{slug}.yaml",
        "operator_signoffs": [],
        "violations_at_last_validator_run": [],
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    write_state(slug, state)
    print(f"CREATED: {path}")
    return 0


def cmd_advance(slug: str, next_cp: str, command: str) -> int:
    if next_cp not in VALID_CHECKPOINTS:
        print(
            f"ERROR: invalid checkpoint '{next_cp}'. "
            f"Valid: {sorted(VALID_CHECKPOINTS)}",
            file=sys.stderr,
        )
        return 3

    try:
        state = read_state(slug)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except IntegrityError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    prev_last = state["last_checkpoint"]
    new_last = state["next_checkpoint"]
    state["last_checkpoint"] = new_last
    state["next_checkpoint"] = next_cp
    state["operator_signoffs"].append({
        "checkpoint": new_last,
        "command": command,
        "at": now_iso(),
    })
    # Clear violations only when advancing forward through CP-D into CP-E
    if new_last == "CP-D" and next_cp in ("CP-E", "DONE"):
        state["violations_at_last_validator_run"] = []

    write_state(slug, state)
    print(f"ADVANCED: {prev_last} → {new_last}; next={next_cp}")
    return 0


def cmd_record_violations(slug: str, checks: list[str]) -> int:
    try:
        state = read_state(slug)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except IntegrityError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    state["violations_at_last_validator_run"] = checks
    write_state(slug, state)
    print(f"RECORDED: {len(checks)} violation check(s) for {slug}")
    return 0


def cmd_clear_violations(slug: str) -> int:
    try:
        state = read_state(slug)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except IntegrityError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    state["violations_at_last_validator_run"] = []
    write_state(slug, state)
    print(f"CLEARED: violations list for {slug}")
    return 0


def cmd_load(slug: str) -> int:
    try:
        state = read_state(slug)
    except FileNotFoundError as e:
        print(f"RESUME_FAILED: {e}", file=sys.stderr)
        return 1
    except IntegrityError as e:
        print(f"RESUME_FAILED: {e}", file=sys.stderr)
        return 2

    print(json.dumps(state, indent=2, ensure_ascii=False))
    return 0


def cmd_finish(slug: str) -> int:
    """Delete state.json — only if output xlsx exists on disk."""
    xlsx = xlsx_path(slug)
    if not xlsx.exists():
        print(
            f"ERROR: refusing to finish — {xlsx} does not exist. "
            f"Build the xlsx via tools/build_page_xlsx.py first.",
            file=sys.stderr,
        )
        return 1

    sp = state_path(slug)
    if not sp.exists():
        print(
            f"WARN: state file already absent at {sp}. Nothing to delete.",
            file=sys.stderr,
        )
        return 0

    sp.unlink()
    print(f"FINISHED: deleted {sp}; xlsx confirmed at {xlsx}")
    return 0


def cmd_abort(slug: str) -> int:
    sp = state_path(slug)
    if not sp.exists():
        print(
            f"WARN: state file not present at {sp}. Nothing to abort.",
            file=sys.stderr,
        )
        return 0

    sp.unlink()
    yp = yaml_path(slug)
    if yp.exists():
        print(
            f"ABORTED: deleted {sp}. Left {yp} in place for manual recovery."
        )
    else:
        print(f"ABORTED: deleted {sp}.")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="State sidecar lifecycle manager.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_create = sub.add_parser("create", help="Initialise state.json at CP-A.")
    p_create.add_argument("slug")
    p_create.add_argument("task_id")

    p_adv = sub.add_parser("advance", help="Advance the checkpoint pointer.")
    p_adv.add_argument("slug")
    p_adv.add_argument("next_checkpoint")
    p_adv.add_argument("--command", required=True,
                       help="Operator command that triggered the advance (e.g. 'proceed').")

    p_rec = sub.add_parser("record-violations",
                           help="Record validator violations without advancing.")
    p_rec.add_argument("slug")
    p_rec.add_argument("checks", nargs="+", help="Check names from validator output.")

    p_clr = sub.add_parser("clear-violations",
                           help="Empty the violations list.")
    p_clr.add_argument("slug")

    p_load = sub.add_parser("load", help="Print current state JSON.")
    p_load.add_argument("slug")

    p_fin = sub.add_parser("finish", help="Delete state.json after xlsx exists.")
    p_fin.add_argument("slug")

    p_abr = sub.add_parser("abort", help="Delete state.json, leave yaml in place.")
    p_abr.add_argument("slug")

    args = parser.parse_args(argv)

    if args.cmd == "create":
        return cmd_create(args.slug, args.task_id)
    if args.cmd == "advance":
        return cmd_advance(args.slug, args.next_checkpoint, args.command)
    if args.cmd == "record-violations":
        return cmd_record_violations(args.slug, args.checks)
    if args.cmd == "clear-violations":
        return cmd_clear_violations(args.slug)
    if args.cmd == "load":
        return cmd_load(args.slug)
    if args.cmd == "finish":
        return cmd_finish(args.slug)
    if args.cmd == "abort":
        return cmd_abort(args.slug)
    return 3


if __name__ == "__main__":
    sys.exit(main())
