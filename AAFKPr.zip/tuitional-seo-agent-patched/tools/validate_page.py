# -*- coding: utf-8 -*-
"""
validate_page.py - Tuitional SEO page YAML validator (patched).

Usage:
    py -3 tools/validate_page.py pages/<slug>.yaml

Replaces the manual counting that previously happened in agent thinking
during Step 7 (completeness checklist) and Step 8 humanizer Pass 2/3.
Exit 0 = all checks pass. Exit 1 = at least one violation.

Validation source: rules from skills.md, humanizer.md, facts.md
(Section 5 banned words is parsed at runtime, not hardcoded).

Optional `_validation` block at the top level of the page YAML lets
the agent declare:
    primary_keyword: "Arabic tutors in Sharjah"
    lsi_terms:
      - "Modern Standard Arabic"
      - "Fusha"
      ...
    faq_templates: ["A", "B", "C", "D", "A", "B"]

If `_validation` is absent the script still runs the structural checks
(word counts, em-dashes, Tuitional cap, etc.) but skips primary-keyword,
LSI, and FAQ-rotation checks.

CHANGES FROM v1 (2026-05-13):
  * Accept both why_igsce (CMS typo) and why_igcse (correct) as the
    component base name. Previously, why_igcse silently bypassed all
    word-count checks.
  * Added contraction ratio check (humanizer Rule 15).
  * Added per-paragraph Tuitional density cap (3 occurrences per slot).
  * Added humanizer-strict sentence-length variation:
    at least one sentence <12 words AND one >22 words per body slot
    with >=3 sentences (was: range>=5).
  * LSI presence now also scans table-cell strings.
  * Banned-word loader prints a sanity line ("loaded N from facts.md")
    so silent fallback is visible.
  * Added optional URL inventory check: if tools/urls.json exists, every
    link target in link_list / why_igsce subjects / popular_subjects must
    appear in the inventory and must not equal the current page URL.
  * `tutor_program` card count now fails on missing/empty cards too
    (not just wrong count).
  * print TOTAL with PASS/FAIL summary line for easier CI parsing.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import yaml


# ---------------------------------------------------------------------------
# Per-slot word count ranges (sourced from skills.md / scaffold inline specs)
# ---------------------------------------------------------------------------

# Map of (component_pattern, field) -> (min_words, max_words).
# Pattern is matched as "startswith" against the component key with the
# numeric suffix stripped (so why_igsce_3 -> why_igsce).
# Both spellings registered so "correcting" why_igsce -> why_igcse doesn't
# silently skip every word-count check.
SLOT_RANGES = {
    ("with_form", "paragraph"): (25, 50),
    ("why_igsce", "paragraph"): (20, 50),
    ("why_igcse", "paragraph"): (20, 50),  # alias for the "correct" spelling
    ("what_our_student_says", "paragraph"): (20, 50),
    ("tutor_program", "card_description"): (20, 30),
    ("Faqs", "answer"): (15, 42),
    ("faqs", "answer"): (15, 42),
}

# Skills.md required-mentions for the parent dashboard
DASHBOARD_FEATURE_KEYWORDS = [
    "attendance",
    "upcoming",
    "schedule",
    "platform update",  # matches "platform updates"
    "chat",
]

# Stopwords used to filter noise from the 3-gram repetition check.
# A 3-gram is reportable only if at most one of its words is a stopword.
STOPWORDS = {
    "the", "a", "an", "of", "to", "is", "in", "on", "for", "and", "or",
    "with", "at", "by", "as", "be", "are", "was", "were", "from", "that",
    "this", "it", "its", "your", "you", "our", "we", "us", "they", "them",
    "their", "his", "her", "she", "he",
}

# Pairs the contractions check is responsible for. Keys are the
# un-contracted forms; values are the contracted form expected as a
# replacement.
CONTRACTABLE = {
    "do not": "don't",
    "does not": "doesn't",
    "did not": "didn't",
    "is not": "isn't",
    "are not": "aren't",
    "was not": "wasn't",
    "were not": "weren't",
    "have not": "haven't",
    "has not": "hasn't",
    "had not": "hadn't",
    "will not": "won't",
    "would not": "wouldn't",
    "could not": "couldn't",
    "should not": "shouldn't",
    "cannot": "can't",
    "can not": "can't",
    "you are": "you're",
    "we are": "we're",
    "they are": "they're",
    "it is": "it's",
    "we have": "we've",
    "you have": "you've",
    "they have": "they've",
    "i have": "i've",
    "we will": "we'll",
    "you will": "you'll",
    "they will": "they'll",
    "i am": "i'm",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class Violation:
    __slots__ = ("slot", "check", "detail", "severity")

    def __init__(self, slot, check, detail, severity="FAIL"):
        self.slot = slot
        self.check = check
        self.detail = detail
        self.severity = severity

    def __str__(self):
        return f"[{self.severity}] {self.slot}: {self.check} | {self.detail}"


def word_count(text):
    if not text:
        return 0
    return len(text.split())


def split_sentences(text):
    if not text:
        return []
    # Split on sentence-final punctuation followed by whitespace or end.
    # Decimals like "4.7" survive (no trailing space). The rare false split
    # at "Dr. Smith" is acceptable because Tuitional body copy doesn't use
    # name abbreviations.
    parts = re.split(r"[.!?]+(?:\s+|$)", text.strip())
    return [p for p in parts if p.strip()]


def count_phrase(text, phrase):
    """Case-insensitive whole-phrase count. Word-boundary aware."""
    if not phrase or not text:
        return 0
    pattern = re.escape(phrase).replace(r"\ ", r"\s+")
    pattern = r"\b" + pattern + r"\b"
    return len(re.findall(pattern, text, flags=re.IGNORECASE))


def base_component(key):
    """why_igsce_3 -> why_igsce. tutor_program_1 -> tutor_program.
    why_igcse_3 -> why_igcse (alias preserved)."""
    parts = key.rsplit("_", 1)
    if len(parts) == 2 and parts[1].isdigit():
        return parts[0]
    return key


def slot_range(component_key, field):
    base = base_component(component_key)
    rng = SLOT_RANGES.get((base, field))
    if rng is not None:
        return rng
    # Defensive alias: if the agent used why_igcse but only why_igsce is
    # registered (or vice versa), fall back to the canonical entry.
    alias = "why_igsce" if base == "why_igcse" else (
        "why_igcse" if base == "why_igsce" else None
    )
    if alias is not None:
        return SLOT_RANGES.get((alias, field))
    return None


# ---------------------------------------------------------------------------
# Body-copy collection
# ---------------------------------------------------------------------------

def collect_body_paragraphs(components):
    """Return [(slot, text, (lo, hi) or None)] for every body-copy item.

    Body copy = paragraphs (`paragraph` fields), card descriptions
    (under `cards`), FAQ answers. Headers, alt text, button labels,
    section labels are not body copy.
    """
    items = []
    for key, data in components.items():
        if not isinstance(data, dict):
            continue

        # paragraph field
        if "paragraph" in data and isinstance(data["paragraph"], str):
            slot = f"{key}.paragraph"
            rng = slot_range(key, "paragraph")
            items.append((slot, data["paragraph"], rng))

        # tutor_program cards
        cards = data.get("cards")
        if isinstance(cards, list):
            for i, card in enumerate(cards):
                if isinstance(card, dict) and isinstance(card.get("description"), str):
                    slot = f"{key}.cards[{i}].description"
                    rng = slot_range(key, "card_description")
                    items.append((slot, card["description"], rng))

        # FAQ items
        if base_component(key).lower() == "faqs":
            faq_items = data.get("items") or data.get("faqs") or []
            for i, item in enumerate(faq_items):
                if isinstance(item, dict) and isinstance(item.get("answer"), str):
                    slot = f"{key}.items[{i}].answer"
                    rng = slot_range(key, "answer")
                    items.append((slot, item["answer"], rng))

    return items


def collect_table_text(components):
    """Pull table-cell strings so LSI can be counted against them too."""
    chunks = []
    for _, data in components.items():
        if not isinstance(data, dict):
            continue
        # Conventional shapes we accept for tables.
        for key in ("rows", "table", "table_rows", "data"):
            v = data.get(key)
            if isinstance(v, list):
                for r in v:
                    if isinstance(r, list):
                        for cell in r:
                            if isinstance(cell, str):
                                chunks.append(cell)
                    elif isinstance(r, dict):
                        for cell in r.values():
                            if isinstance(cell, str):
                                chunks.append(cell)
    return " ".join(chunks)


def full_page_text(components):
    """Body copy + headers + meta_tags strings, for cross-page counts
    (Tuitional total, primary keyword exact)."""
    chunks = []
    for _, data in components.items():
        if isinstance(data, dict):
            for v in walk_strings(data):
                chunks.append(v)
        elif isinstance(data, str):
            chunks.append(data)
    return " ".join(chunks)


def walk_strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from walk_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from walk_strings(v)


# ---------------------------------------------------------------------------
# Banned-word loading from facts.md
# ---------------------------------------------------------------------------

# Hard-banned phrases. Loaded from facts.md Section 5 if available, else
# fallback to this hardcoded copy taken verbatim from facts.md 2026-05-06.
HARD_BANNED_FALLBACK = [
    "Cheap", "Cheapest", "Low-cost", "Limited time offer", "Act now",
    "Hurry up", "Buy now", "Don't miss out", "Instant results", "Expert",
    "Could improve", "Hopefully", "Weak students", "Poor performers",
]


def load_banned_words(repo_root, verbose=True):
    """Read facts.md Section 5 hard-banned list. Falls back if unreadable.

    Prints a sanity line so silent fallback is visible to the operator.
    """
    facts_path = repo_root / "facts.md"
    if not facts_path.exists():
        if verbose:
            print(
                f"[validator] WARNING: facts.md not found at {facts_path}. "
                f"Using hardcoded fallback ({len(HARD_BANNED_FALLBACK)} terms).",
                file=sys.stderr,
            )
        return HARD_BANNED_FALLBACK
    try:
        text = facts_path.read_text(encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        if verbose:
            print(
                f"[validator] WARNING: facts.md unreadable ({exc}). "
                f"Using hardcoded fallback.",
                file=sys.stderr,
            )
        return HARD_BANNED_FALLBACK

    # The hard-banned list lives in a blockquote line that starts with "> "
    # and contains comma-separated phrases. We grab the first such line
    # after the "Hard-Banned Words" section heading.
    in_section = False
    for line in text.splitlines():
        if "Hard-Banned Words" in line:
            in_section = True
            continue
        if in_section and line.startswith("> "):
            raw = line[2:].strip()
            if raw and "," in raw:
                words = [w.strip() for w in raw.split(",") if w.strip()]
                if verbose:
                    print(
                        f"[validator] Loaded {len(words)} banned terms from facts.md.",
                        file=sys.stderr,
                    )
                return words

    if verbose:
        print(
            "[validator] WARNING: facts.md present but Hard-Banned blockquote "
            "not found. Using hardcoded fallback.",
            file=sys.stderr,
        )
    return HARD_BANNED_FALLBACK


# ---------------------------------------------------------------------------
# URL inventory loading (optional)
# ---------------------------------------------------------------------------

def load_url_inventory(repo_root):
    """Optional. If tools/urls.json exists, return a set of canonical URLs.
    Returns None if absent (the URL-inventory check is then skipped)."""
    path = repo_root / "tools" / "urls.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        urls = set()
        for entry in data.get("pages", []):
            url = entry.get("url")
            if url:
                urls.add(url.strip())
        return urls
    except Exception as exc:  # noqa: BLE001
        print(
            f"[validator] WARNING: tools/urls.json unreadable ({exc}). "
            f"Skipping URL inventory check.",
            file=sys.stderr,
        )
        return None


def collect_link_targets(components):
    """Return [(slot, url)] for every internal link the page declares."""
    out = []
    for key, data in components.items():
        if not isinstance(data, dict):
            continue
        # link_list / popular_subjects / main_content style: items[].link
        # and subjects[].link (both shapes seen across scaffolds).
        for arr_key in ("items", "subjects"):
            arr = data.get(arr_key)
            if isinstance(arr, list):
                for i, it in enumerate(arr):
                    if isinstance(it, dict):
                        link = it.get("link")
                        if isinstance(link, str) and link.strip():
                            out.append((f"{key}.{arr_key}[{i}].link", link.strip()))
    return out


# ---------------------------------------------------------------------------
# Pattern checks
# ---------------------------------------------------------------------------

def find_repeated_3grams(text, max_count=2):
    """Return list of (phrase, count) for 3-word phrases that exceed max_count.
    Filters out phrases where 2+ words are stopwords."""
    tokens = re.findall(r"\w[\w'-]*", text.lower())
    counts = {}
    for i in range(len(tokens) - 2):
        gram = tokens[i:i + 3]
        if sum(1 for t in gram if t in STOPWORDS) >= 2:
            continue
        key = " ".join(gram)
        counts[key] = counts.get(key, 0) + 1
    return sorted(
        ((p, c) for p, c in counts.items() if c > max_count),
        key=lambda x: -x[1],
    )


def contraction_ratio(text):
    """Return (eligible, contracted) where eligible is the count of
    uncontracted-or-contracted instances and contracted is how many of
    those are in contracted form.
    """
    tl = text.lower()
    eligible = 0
    contracted = 0
    for un, co in CONTRACTABLE.items():
        un_re = r"\b" + re.escape(un).replace(r"\ ", r"\s+") + r"\b"
        eligible += len(re.findall(un_re, tl))
        co_re = r"\b" + re.escape(co) + r"\b"
        hits = len(re.findall(co_re, tl))
        eligible += hits
        contracted += hits
    return eligible, contracted


def classify_opener(sentence):
    """Coarse classification for sentence-initial uniformity check.

    Returns one of: 'noun', 'verb_imp', 'subord', 'question', 'participial',
    'pp', 'conj', 'other'.
    """
    s = sentence.strip()
    if not s:
        return "other"
    if s.endswith("?"):
        return "question"
    first_word = re.match(r"\w[\w'-]*", s)
    if not first_word:
        return "other"
    w = first_word.group(0).lower()
    if w in ("but", "and", "or", "so", "yet"):
        return "conj"
    if w in ("before", "after", "when", "while", "if", "because", "although",
             "though", "since", "until"):
        return "subord"
    if w in ("matched", "built", "based", "trained", "designed", "set",
             "given", "taught", "shaped"):
        return "participial"
    if w in ("for", "with", "at", "in", "on", "from", "between", "across",
             "by", "during", "within"):
        return "pp"
    if w in ("book", "schedule", "start", "find", "get", "join", "ask",
             "see", "explore"):
        return "verb_imp"
    return "noun"


# ---------------------------------------------------------------------------
# Main validation
# ---------------------------------------------------------------------------

def validate_page(page, repo_root):
    violations = []
    components = page.get("components") or {}
    if not isinstance(components, dict):
        violations.append(Violation("page", "structure", "'components' is not a mapping"))
        return violations

    meta = page.get("_validation") or {}
    primary_keyword = meta.get("primary_keyword", "")
    lsi_terms = meta.get("lsi_terms") or []
    faq_templates = meta.get("faq_templates") or []
    page_slug = page.get("pageSlug") or ""

    body_items = collect_body_paragraphs(components)
    body_text = " ".join(t for _, t, _ in body_items)
    page_text = full_page_text(components)
    table_text = collect_table_text(components)

    # 1. Word count per slot
    for slot, text, rng in body_items:
        wc = word_count(text)
        if rng is None:
            continue
        lo, hi = rng
        if wc < lo or wc > hi:
            violations.append(Violation(
                slot, "word_count", f"{wc} words (range {lo}-{hi})"
            ))

    # 2. Sentence cap (30 words)
    for slot, text, _ in body_items:
        for sent in split_sentences(text):
            sw = word_count(sent)
            if sw > 30:
                violations.append(Violation(
                    slot, "sentence_cap",
                    f"{sw}-word sentence: {sent[:60]}...",
                ))

    # 3. Primary keyword exact-match count
    if primary_keyword:
        c = count_phrase(page_text, primary_keyword)
        if c > 3:
            violations.append(Violation(
                "page", "primary_keyword_density",
                f"'{primary_keyword}' x{c} (max 3)",
            ))

    # 4. Tuitional total mentions (across full page including meta)
    t_total = count_phrase(page_text, "Tuitional")
    if t_total > 8:
        violations.append(Violation(
            "page", "tuitional_total", f"{t_total} mentions (max 8)"
        ))

    # 4b. Per-paragraph Tuitional density (NEW). A single slot stuffed
    # with "Tuitional" repeats is the recurring failure mode the page-total
    # cap doesn't catch.
    for slot, text, _ in body_items:
        c = count_phrase(text, "Tuitional")
        if c > 3:
            violations.append(Violation(
                slot, "tuitional_per_slot",
                f"'Tuitional' x{c} in this slot (max 3)",
            ))

    # 5. Tuitional opener percentage
    if body_items:
        tuitional_openers = sum(
            1 for _, t, _ in body_items
            if t.strip().lower().startswith("tuitional")
        )
        pct = tuitional_openers / len(body_items)
        if pct > 0.30:
            violations.append(Violation(
                "page", "tuitional_opener_pct",
                f"{tuitional_openers}/{len(body_items)} = {pct:.0%} (max 30%)",
            ))

    # 6. Em/en dash scan in body copy
    for slot, text, _ in body_items:
        if "\u2014" in text or "\u2013" in text:
            violations.append(Violation(
                slot, "em_en_dash", "em or en dash present (zero tolerance)",
            ))

    # 7. 3-word phrase repetition (>2 occurrences)
    for phrase, count in find_repeated_3grams(body_text, max_count=2):
        violations.append(Violation(
            "page", "phrase_repeat", f"'{phrase}' x{count} (max 2)"
        ))

    # 8. LSI presence (each >=2). Now also scans table-cell text so terms
    # placed in a syllabus table count.
    lsi_scan_text = body_text + " " + table_text
    for term in lsi_terms:
        c = count_phrase(lsi_scan_text, term)
        if c < 2:
            violations.append(Violation(
                "page", "lsi_presence", f"'{term}' x{c} (need >=2)"
            ))

    # 9. FAQ template rotation
    for i in range(1, len(faq_templates)):
        if faq_templates[i] == faq_templates[i - 1]:
            violations.append(Violation(
                f"Faqs.items[{i}]", "template_rotation",
                f"template '{faq_templates[i]}' same as items[{i - 1}]",
            ))

    # 10. Five-feature dashboard rule
    for slot, text, _ in body_items:
        if "dashboard" in text.lower():
            missing = [
                k for k in DASHBOARD_FEATURE_KEYWORDS
                if k not in text.lower()
            ]
            if missing:
                violations.append(Violation(
                    slot, "dashboard_features",
                    f"missing: {', '.join(missing)}",
                ))

    # 11. Banned words (hard list from facts.md)
    banned = load_banned_words(repo_root)
    for w in banned:
        pattern = r"\b" + re.escape(w).replace(r"\ ", r"\s+") + r"\b"
        if re.search(pattern, body_text, flags=re.IGNORECASE):
            violations.append(Violation(
                "page", "banned_word", f"'{w}'"
            ))

    # 12. Card counts (now also fails when cards are missing/empty)
    tp = components.get("tutor_program")
    if isinstance(tp, dict):
        cards = tp.get("cards") or []
        if len(cards) != 6:
            violations.append(Violation(
                "tutor_program", "card_count",
                f"{len(cards)} cards (expected 6)",
            ))
    tp1 = components.get("tutor_program_1")
    if isinstance(tp1, dict):
        cards = tp1.get("cards") or []
        if len(cards) != 3:
            violations.append(Violation(
                "tutor_program_1", "card_count",
                f"{len(cards)} cards (expected 3)",
            ))

    # 13. Sentence-length variation per body slot.
    # Humanizer's strict rule: at least one sentence under 12 words AND
    # at least one over 22 words per component with >=3 sentences.
    # The rule says "where the content naturally supports it" — so skip
    # for FAQ answers (15-42 word range can't fit a 22+ sentence) and
    # card descriptions (20-30 word cap). Keep it for paragraph slots.
    for slot, text, rng in body_items:
        if ".items[" in slot:        # FAQ answer
            continue
        if ".cards[" in slot:        # tutor_program card description
            continue
        sentences = split_sentences(text)
        if len(sentences) >= 3:
            lengths = [word_count(s) for s in sentences]
            if min(lengths) >= 12 or max(lengths) <= 22:
                violations.append(Violation(
                    slot, "sentence_variation",
                    f"lengths {lengths} (need >=1 sentence <12 AND >=1 >22)",
                ))

    # 14. Contraction ratio per slot (humanizer Rule 15: >=50% of eligible
    # contractable pairs in body copy and FAQ answers are contracted).
    for slot, text, _ in body_items:
        eligible, contracted = contraction_ratio(text)
        if eligible >= 2 and (contracted / eligible) < 0.5:
            violations.append(Violation(
                slot, "contraction_ratio",
                f"{contracted}/{eligible} = {contracted/eligible:.0%} (need >=50%)",
            ))

    # 15. Sentence-initial uniformity (humanizer Rule 16).
    # Flag any run of 3+ consecutive sentences with the same opener class
    # within a single slot. Skip slots with <3 sentences (rule is undefined)
    # and skip FAQ answers (too short to meaningfully rotate openers).
    for slot, text, _ in body_items:
        if ".items[" in slot:
            continue
        sentences = split_sentences(text)
        if len(sentences) < 3:
            continue
        classes = [classify_opener(s) for s in sentences]
        run = 1
        for i in range(1, len(classes)):
            if classes[i] == classes[i - 1]:
                run += 1
                if run >= 3:
                    violations.append(Violation(
                        slot, "opener_uniformity",
                        f"3+ consecutive '{classes[i]}' openers",
                    ))
                    break
            else:
                run = 1

    # 16. URL inventory check (optional — runs only if tools/urls.json exists)
    inv = load_url_inventory(repo_root)
    if inv is not None:
        link_targets = collect_link_targets(components)
        seen = set()
        current_url = None
        if page_slug:
            current_url = f"https://tuitionaledu.com/online/{page_slug}"
        for slot, url in link_targets:
            if url not in inv:
                violations.append(Violation(
                    slot, "url_not_in_inventory", f"'{url}'"
                ))
            if current_url and url == current_url:
                violations.append(Violation(
                    slot, "self_link", f"'{url}' is the current page"
                ))
            if url in seen:
                violations.append(Violation(
                    slot, "duplicate_link", f"'{url}' appears more than once"
                ))
            seen.add(url)

    return violations


# ---------------------------------------------------------------------------
# Main / CLI
# ---------------------------------------------------------------------------

def load_pages(yaml_path):
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if data is None:
        raise ValueError(f"{yaml_path} is empty")
    if isinstance(data, dict) and "pages" in data:
        return data["pages"]
    if isinstance(data, list):
        return data
    return [data]


def main():
    ap = argparse.ArgumentParser(
        description="Validate a Tuitional page YAML against rules from "
                    "skills.md / humanizer.md / facts.md.",
    )
    ap.add_argument("yaml_file", help="Path to the page YAML")
    args = ap.parse_args()

    yaml_path = Path(args.yaml_file)
    if not yaml_path.exists():
        print(f"ERROR: {yaml_path} not found", file=sys.stderr)
        sys.exit(2)

    repo_root = yaml_path.resolve().parent.parent

    pages = load_pages(yaml_path)
    total_violations = 0
    for i, page in enumerate(pages):
        slug = page.get("pageSlug") or f"page-{i+1}"
        viols = validate_page(page, repo_root)
        if viols:
            print(f"=== {slug}: {len(viols)} violation(s) ===")
            for v in viols:
                print(str(v))
            print()
        else:
            print(f"=== {slug}: PASS ===")
        total_violations += len(viols)

    if total_violations:
        print(f"TOTAL: {total_violations} violation(s) - FAIL")
        sys.exit(1)
    else:
        print("TOTAL: 0 violations - PASS")
        sys.exit(0)


if __name__ == "__main__":
    main()
