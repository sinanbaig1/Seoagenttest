#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_url_inventory.py - Parse tuitional_interlinking_agent.md and emit
tools/urls.json with one entry per live page.

Usage:
    py -3 tools/build_url_inventory.py

Why this exists:
    The interlinking agent's source of truth is currently a 752-line
    markdown file. validate_page.py and the interlinking agent both
    need it as data. This script parses the prose-grouped lists
    into a JSON that both can consume.

Output shape:
    {
      "generated_from": "tuitional_interlinking_agent.md",
      "generated_at": "<ISO timestamp>",
      "pages": [
        {"name": "GCSE Tutors", "url": "https://tuitionaledu.com/online/gcse-tutors", "category": "Board / Level Landing"},
        ...
      ]
    }

The script is idempotent. Re-run after every inventory edit and commit
the JSON alongside the markdown.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path


HEADER_RE = re.compile(r"^###\s+(.+?)(?:\s+\(\d+\s+pages\))?\s*$")
SUBHEADER_RE = re.compile(r"^\*\*(.+?):\*\*\s*$")  # **Biology:** style subheaders
ENTRY_RE = re.compile(
    r"^-\s+(?P<name>.+?)\s+(?:→|->)\s+(?P<url>https?://\S+)\s*$"
)


def parse_inventory(md_text: str):
    """Walk the markdown and emit a list of {name, url, category} dicts.

    The inventory section starts at the `## COMPLETE PAGE INVENTORY`
    heading. Anything before that is ignored.
    """
    in_inventory = False
    category = None
    parent_category = None
    pages = []
    seen_urls = set()

    for raw in md_text.splitlines():
        line = raw.rstrip()

        if not in_inventory:
            if "COMPLETE PAGE INVENTORY" in line:
                in_inventory = True
            continue

        # Stop at the next H2 (or H1) after the inventory.
        if line.startswith("## ") and "INVENTORY" not in line:
            break

        h = HEADER_RE.match(line)
        if h:
            parent_category = h.group(1).strip()
            category = parent_category
            continue

        sh = SUBHEADER_RE.match(line)
        if sh:
            # A subheader (e.g. "**Biology:**") refines the current H3.
            # It does NOT stack with previous subheaders.
            sub = sh.group(1).strip()
            category = f"{parent_category} - {sub}" if parent_category else sub
            continue

        m = ENTRY_RE.match(line)
        if m:
            name = m.group("name").strip()
            url = m.group("url").strip().rstrip(".,;:")
            if url in seen_urls:
                continue
            seen_urls.add(url)
            pages.append({
                "name": name,
                "url": url,
                "category": category or "Uncategorised",
            })

    return pages


def main():
    repo_root = Path(__file__).resolve().parent.parent
    src = repo_root / "tuitional_interlinking_agent.md"
    out = repo_root / "tools" / "urls.json"

    if not src.exists():
        print(f"ERROR: {src} not found", file=sys.stderr)
        sys.exit(1)

    md = src.read_text(encoding="utf-8")
    pages = parse_inventory(md)

    if not pages:
        print(
            "ERROR: parsed 0 pages from inventory. "
            "Check the markdown format (expects '- Name → URL' lines under "
            "'## COMPLETE PAGE INVENTORY').",
            file=sys.stderr,
        )
        sys.exit(1)

    payload = {
        "generated_from": "tuitional_interlinking_agent.md",
        "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "count": len(pages),
        "pages": pages,
    }

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                   encoding="utf-8")
    print(f"Wrote {len(pages)} pages to {out}")


if __name__ == "__main__":
    main()
