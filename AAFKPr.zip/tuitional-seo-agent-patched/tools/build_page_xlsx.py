# -*- coding: utf-8 -*-
"""
build_page_xlsx.py - Tuitional SEO page YAML to CMS-ready xlsx converter.

Usage:
    py -3 tools/build_page_xlsx.py pages/<slug>.yaml
    py -3 tools/build_page_xlsx.py pages/<slug>.yaml --out output/<slug>.xlsx

Input: a YAML file describing one page in component->field->value form.
Output: an xlsx matching the cat-loc-template.xlsx layout (one sheet per page),
        with tutor_program HTML/CSS card grids assembled automatically.

Why this exists:
    The agent used to write Python ad-hoc each session to produce xlsx output.
    That caused encoding errors, structural drift, and 5-10 minutes of
    overhead per page. This script is the single committed artefact for
    that step.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import yaml
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill


# ---------------------------------------------------------------------------
# tutor_program HTML/CSS - lifted verbatim from component-variance.md
# Format A: 6 feature cards. Format B: 3 sign-up steps. Same wrapper.
# ---------------------------------------------------------------------------

TUTOR_PROGRAM_CSS = (
    "<style>"
    ".tuitional-program-section{max-width:1100px;margin:20px auto;"
    "padding:10px;color:#333;line-height:1.6;}"
    ".program-grid{display:grid;"
    "grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:25px;}"
    ".program-card{padding:25px;border-radius:12px;"
    "border:1px solid rgba(0,0,0,0.08);"
    "transition:transform 0.3s ease,box-shadow 0.3s ease;"
    "background:rgba(255,255,255,0.4);backdrop-filter:blur(5px);"
    "-webkit-backdrop-filter:blur(5px);}"
    ".program-card:hover{transform:translateY(-5px);"
    "box-shadow:0 10px 20px rgba(0,0,0,0.05);border-color:#3498db;}"
    ".program-card h3{margin:0 0 12px 0;font-size:1.25rem;color:#2c3e50;"
    "display:flex;align-items:center;font-weight:700;}"
    ".program-card h3::before{content:'\\2713';margin-right:12px;color:#3498db;"
    "font-weight:bold;background:rgba(52,152,219,0.1);"
    "width:28px;height:28px;min-width:28px;display:flex;"
    "align-items:center;justify-content:center;border-radius:50%;"
    "font-size:0.85rem;}"
    ".program-card p{margin:0;font-size:0.95rem;color:#555;}"
    "@media (max-width:768px){.program-grid{grid-template-columns:1fr;}}"
    "</style>"
)


def render_tutor_program_html(cards):
    """Build the tutor_program paragraph HTML from a list of card dicts.

    Each card: {title: str, description: str}
    Format A expects 6 cards, Format B expects 3. The wrapper is identical;
    the difference is purely the number of cards passed in.
    """
    if not cards:
        return ""
    card_html = "".join(
        '<div class="program-card"><h3>{t}</h3><p>{d}</p></div>'.format(
            t=(c.get("title") or "").strip(),
            d=(c.get("description") or "").strip(),
        )
        for c in cards
    )
    return (
        TUTOR_PROGRAM_CSS
        + '<section class="tuitional-program-section">'
        + '<div class="program-grid">'
        + card_html
        + '</div></section>'
    )


# ---------------------------------------------------------------------------
# Component field expansion
# ---------------------------------------------------------------------------

def expand_component(component_key, comp_data):
    """Convert one component block from YAML into a list of (field, value) pairs.

    Three special cases:
      - tutor_program / tutor_program_*: cards block becomes paragraph HTML
      - Faqs / faqs: items list expands to faqs[i].question / faqs[i].answer
      - link_list: items list expands to subjects[i].name / subjects[i].link
    Everything else is a flat field->value map.
    """
    base = component_key.split("_")[0] if "_" in component_key else component_key
    rows = []

    if isinstance(comp_data, dict):
        # tutor_program: assemble the HTML card grid into the paragraph field
        if component_key.startswith("tutor_program"):
            cards = comp_data.get("cards")
            if cards is not None:
                comp_data = dict(comp_data)
                comp_data["paragraph"] = render_tutor_program_html(cards)
                comp_data.pop("cards", None)
                comp_data.pop("format", None)

        # Faqs: items[] -> faqs[i].question / faqs[i].answer
        if component_key.lower() == "faqs":
            items = comp_data.get("items") or comp_data.get("faqs")
            if items is not None:
                # Flat fields first (header, headerTag, paragraph)
                for k, v in comp_data.items():
                    if k in ("items", "faqs"):
                        continue
                    rows.append((k, v))
                for i, item in enumerate(items):
                    rows.append((f"faqs[{i}].question", item.get("question", "")))
                    rows.append((f"faqs[{i}].answer", item.get("answer", "")))
                return rows

        # link_list: items[] -> subjects[i].name / subjects[i].link
        if component_key == "link_list":
            items = comp_data.get("items") or comp_data.get("subjects")
            if items is not None:
                for k, v in comp_data.items():
                    if k in ("items", "subjects"):
                        continue
                    rows.append((k, v))
                for i, item in enumerate(items):
                    rows.append((f"subjects[{i}].name", item.get("name", "")))
                    rows.append((f"subjects[{i}].link", item.get("link", "")))
                return rows

        # Plain component: every key becomes one field row
        for k, v in comp_data.items():
            rows.append((k, v))

    elif isinstance(comp_data, bool):
        rows.append(("isShow", comp_data))
    elif comp_data is None:
        pass
    else:
        rows.append(("value", comp_data))

    return rows


# ---------------------------------------------------------------------------
# Sheet building
# ---------------------------------------------------------------------------

HEADER_FONT = Font(bold=True)
SEPARATOR_FILL = PatternFill(start_color="DDDDDD", end_color="DDDDDD",
                             fill_type="solid")


def build_sheet(ws, page):
    """Populate one worksheet with the page rows.

    Layout matches cat-loc-template.xlsx:
      pageName | <name>
      pageSlug | <slug>
      variant  | <variant>
      ---
      <component> | <field> | <value>
      ...
    """
    page_name = page.get("pageName", "")
    page_slug = page.get("pageSlug", "")
    variant = page.get("variant", "new")

    ws.append(["pageName", page_name, None])
    ws.append(["pageSlug", page_slug, None])
    ws.append(["variant", variant, None])
    ws.append(["---", None, None])

    components = page.get("components") or {}
    if not isinstance(components, dict):
        raise ValueError("'components' must be a mapping of component_key to data")

    for component_key, comp_data in components.items():
        for field, value in expand_component(component_key, comp_data):
            if isinstance(value, bool):
                cell_value = "true" if value else "false"
            elif value is None:
                cell_value = None
            else:
                cell_value = str(value)
            ws.append([component_key, field, cell_value])

    # Column widths and value-cell wrapping for readability
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 110
    for row in ws.iter_rows():
        for cell in row:
            if cell.column == 3:
                cell.alignment = Alignment(wrap_text=True, vertical="top")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def load_pages(yaml_path):
    """Load a YAML file. Returns a list of page dicts.

    Supports two shapes:
      - Single page: top-level keys pageName, pageSlug, components
      - Multi-page: top-level 'pages' list
    """
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if data is None:
        raise ValueError(f"{yaml_path} is empty")

    if isinstance(data, dict) and "pages" in data:
        return data["pages"]
    if isinstance(data, list):
        return data
    return [data]


def main():
    ap = argparse.ArgumentParser(
        description="Convert a Tuitional page YAML into a CMS-ready xlsx."
    )
    ap.add_argument("yaml_file", help="Path to the page YAML")
    ap.add_argument("--out", help="Output xlsx path "
                                  "(default: output/<slug>.xlsx)")
    args = ap.parse_args()

    yaml_path = Path(args.yaml_file)
    if not yaml_path.exists():
        print(f"ERROR: {yaml_path} not found", file=sys.stderr)
        sys.exit(1)

    pages = load_pages(yaml_path)
    if not pages:
        print("ERROR: no pages in YAML", file=sys.stderr)
        sys.exit(1)

    if args.out:
        out_path = Path(args.out)
    else:
        first_slug = pages[0].get("pageSlug") or yaml_path.stem
        out_path = Path("output") / f"{first_slug}.xlsx"

    out_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    wb.remove(wb.active)

    for i, page in enumerate(pages):
        sheet_name = page.get("pageSlug") or f"page-{i+1}"
        sheet_name = sheet_name[:31]
        ws = wb.create_sheet(title=sheet_name)
        build_sheet(ws, page)

    wb.save(out_path)
    print(f"Saved: {out_path.resolve()}")
    print(f"Sheets: {len(pages)}")


if __name__ == "__main__":
    main()
