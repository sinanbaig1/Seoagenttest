#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_tests.py - smoke tests for validate_page.py and build_url_inventory.py.

Usage:
    py -3 tools/run_tests.py

Exit code 0 = all tests pass. Non-zero = at least one regression.

Tests:
    1. tests/golden_pass.yaml must exit 0 with 0 violations.
    2. tests/golden_fail.yaml must exit 1 with the expected check names.
    3. tools/urls.json must exist and contain >= 300 page entries.
    4. The validator's why_igcse alias must work
       (the recurring silent-pass regression).
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
VALIDATOR = REPO_ROOT / "tools" / "validate_page.py"


def run_validator(yaml_path: Path):
    """Return (exit_code, stdout)."""
    proc = subprocess.run(
        [sys.executable, str(VALIDATOR), str(yaml_path)],
        capture_output=True,
        text=True,
    )
    return proc.returncode, proc.stdout


def test_golden_pass():
    yaml_path = REPO_ROOT / "tests" / "golden_pass.yaml"
    rc, out = run_validator(yaml_path)
    if rc != 0:
        print(f"[FAIL] golden_pass should exit 0, got {rc}")
        print(out)
        return False
    if "PASS" not in out:
        print(f"[FAIL] golden_pass output missing PASS")
        print(out)
        return False
    print("[OK]   golden_pass: validator exit 0")
    return True


def test_golden_fail():
    yaml_path = REPO_ROOT / "tests" / "golden_fail.yaml"
    rc, out = run_validator(yaml_path)
    if rc == 0:
        print("[FAIL] golden_fail should exit 1, got 0")
        print(out)
        return False

    # Spot-check that the expected checks fired.
    expected_checks = [
        "word_count",            # paragraph too short or too long
        "em_en_dash",            # em dash in body
        "banned_word",           # "Expert"
        "tuitional_per_slot",    # 4x Tuitional in why_igsce
        "dashboard_features",    # dashboard mentioned without all 5
        "template_rotation",     # consecutive A and consecutive D
        "card_count",            # tutor_program with 0 cards
        "contraction_ratio",     # uncontracted forms
    ]
    missing = [c for c in expected_checks if c not in out]
    if missing:
        print(f"[FAIL] golden_fail did not fire: {missing}")
        print(out)
        return False
    print(f"[OK]   golden_fail: validator exit {rc}, all expected checks fired")
    return True


def test_alias_no_silent_pass():
    """The recurring regression: paragraph: 'x' under why_igcse must FAIL."""
    yaml = """\
pageName: "Test"
pageSlug: "test-alias"
variant: new
_validation:
  primary_keyword: "x"
  lsi_terms: []
  faq_templates: []
components:
  why_igcse:
    header: "H"
    headerTag: h2
    paragraph: "x"
"""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False
    ) as f:
        f.write(yaml)
        p = Path(f.name)
    try:
        rc, out = run_validator(p)
        if rc == 0:
            print("[FAIL] alias check: 1-word paragraph under why_igcse passed validation")
            print(out)
            return False
        if "word_count" not in out:
            print("[FAIL] alias check: word_count violation not reported")
            print(out)
            return False
        print("[OK]   alias: why_igcse 1-word paragraph correctly flagged")
        return True
    finally:
        p.unlink(missing_ok=True)


def test_url_inventory_exists():
    path = REPO_ROOT / "tools" / "urls.json"
    if not path.exists():
        print(f"[WARN] tools/urls.json missing. Run build_url_inventory.py.")
        return False
    data = json.loads(path.read_text(encoding="utf-8"))
    n = len(data.get("pages", []))
    if n < 300:
        print(f"[FAIL] tools/urls.json only has {n} entries (expected >=300).")
        return False
    print(f"[OK]   url inventory: {n} entries loaded")
    return True


def main():
    tests = [
        ("golden_pass", test_golden_pass),
        ("golden_fail", test_golden_fail),
        ("alias_no_silent_pass", test_alias_no_silent_pass),
        ("url_inventory_exists", test_url_inventory_exists),
    ]
    failures = []
    for name, fn in tests:
        try:
            ok = fn()
        except Exception as exc:  # noqa: BLE001
            print(f"[FAIL] {name}: exception {exc}")
            ok = False
        if not ok:
            failures.append(name)

    print()
    if failures:
        print(f"FAIL: {len(failures)}/{len(tests)} test(s) failed: {failures}")
        sys.exit(1)
    print(f"PASS: {len(tests)}/{len(tests)} tests passed")


if __name__ == "__main__":
    main()
