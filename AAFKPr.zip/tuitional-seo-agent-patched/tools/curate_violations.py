# -*- coding: utf-8 -*-
"""
curate_violations.py — Run validate_page.py and emit the Bug Curation block.

Used at CP-D to produce the deterministic curation report when the validator
reports violations. Never write the curation block by hand — always use this
script.

Usage:
    py -3 tools/curate_violations.py pages/<slug>.yaml

Exit codes:
    0 — validator passed, no curation needed
    1 — validator failed; curation block printed to stdout
    2 — validator could not run (missing file, parse error)

The curation block is printed to stdout and matches the format defined in
claude.md Bug Curation Protocol verbatim, so it can be pasted directly into
the agent's CP-D response.

The script also calls `tools/state_manager.py record-violations` to persist
the violation list into the state sidecar. If state_manager is unavailable,
the curation block still prints — only the sidecar update is skipped, with
a stderr warning.
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
VALIDATOR = REPO_ROOT / "tools" / "validate_page.py"
STATE_MANAGER = REPO_ROOT / "tools" / "state_manager.py"


# ---------------------------------------------------------------------------
# Fix-scope mapping (mirrors claude.md Bug Curation Protocol)
# ---------------------------------------------------------------------------

FIX_SCOPE_MAP: dict[str, dict[str, str]] = {
    "word_count": {
        "scope": "CP-C",
        "cause": "Slot prose is over or under the declared word range.",
    },
    "sentence_cap": {
        "scope": "CP-C",
        "cause": "One sentence exceeds 30 words — split at a comma or colon.",
    },
    "primary_keyword_density": {
        "scope": "CP-C",
        "cause": "Primary keyword appears more than 3 times across the full page (case-insensitive). "
                 "Usually meta_tags duplicates (pageSchemaName, metaName[0], metaName[1]) push the count over.",
    },
    "tuitional_total": {
        "scope": "CP-C",
        "cause": "Brand mentioned more than 8 times across the full page. "
                 "Common cause: redundant 'Tuitional' in FAQ answers when meta carries the brand.",
    },
    "tuitional_opener_pct": {
        "scope": "CP-C",
        "cause": "More than 30% of body paragraphs open with 'Tuitional'. "
                 "Rewrite some openers to start with the subject, the student, or a fact.",
    },
    "em_en_dash": {
        "scope": "CP-C",
        "cause": "Em-dash (—) or en-dash (–) present in body copy. Replace with comma or split sentence. "
                 "Note: '87-97.2%' must use a regular hyphen, not en-dash, even though facts.md displays an en-dash.",
    },
    "phrase_repeat": {
        "scope": "CP-C",
        "cause": "A 3-word phrase (non-stopword-dominant) appears more than twice in body copy. "
                 "Vary verbs/phrasing — most repeats come from over-using 'Academic Consultant matches' "
                 "or '<subject> tutors in <city>' phrases across multiple slots.",
    },
    "lsi_presence": {
        "scope": "CP-C",
        "cause": "An LSI term in _validation.lsi_terms appears fewer than 2 times in body copy. "
                 "If the term is wrong for this subject, fix _validation in CP-B (scope changes to CP-B). "
                 "Otherwise seed the term into one more body paragraph or FAQ answer by REWRITING a sentence, "
                 "not by appending — see memory.md Entry #7.",
    },
    "template_rotation": {
        "scope": "CP-C",
        "cause": "Two consecutive FAQs use the same A/B/C/D template. "
                 "If the answer text no longer fits the assigned template, rewrite the answer in CP-C. "
                 "If the original CP-B template assignment was wrong, scope changes to CP-B.",
    },
    "dashboard_features": {
        "scope": "CP-C",
        "cause": "A paragraph mentions 'dashboard' but omits one of the five facts.md Section 2 features: "
                 "attendance, upcoming classes, real-time schedule, platform updates, real-time chat.",
    },
    "banned_word": {
        "scope": "CP-C",
        "cause": "A facts.md Section 5 banned word is present. Replace per the approved alternatives "
                 "in facts.md Sections 5 and 6.",
    },
    "card_count": {
        "scope": "CP-B",
        "cause": "Structural: tutor_program must have exactly 6 cards, tutor_program_1 exactly 3. "
                 "Fix in the scaffold copy at CP-B (re-run CP-B), not in CP-C.",
    },
    "sentence_variation": {
        "scope": "CP-C",
        "cause": "A multi-sentence slot has < 5 words spread between shortest and longest sentence. "
                 "Rewrite one sentence shorter or longer.",
    },
}


# ---------------------------------------------------------------------------
# Validator output parsing
# ---------------------------------------------------------------------------

VIOLATION_RE = re.compile(
    r"^\[FAIL\]\s+(?P<slot>[^:]+):\s+(?P<check>\S+)\s+\|\s+(?P<detail>.+)$"
)


def parse_validator_output(stdout: str) -> list[dict[str, str]]:
    """Extract [FAIL] lines into structured violation records."""
    violations = []
    for line in stdout.splitlines():
        m = VIOLATION_RE.match(line.strip())
        if m:
            violations.append({
                "slot": m.group("slot"),
                "check": m.group("check"),
                "detail": m.group("detail"),
            })
    return violations


# ---------------------------------------------------------------------------
# Root cause synthesis
# ---------------------------------------------------------------------------

def root_cause_summary(violations: list[dict[str, str]]) -> str:
    """Produce a 2-4 sentence narrative about whether violations share a cause."""
    if not violations:
        return "No violations to summarise."

    by_check = Counter(v["check"] for v in violations)
    by_scope = Counter(
        FIX_SCOPE_MAP.get(v["check"], {}).get("scope", "CP-C")
        for v in violations
    )
    total = len(violations)
    distinct_checks = len(by_check)

    # Detect clustered phrase_repeat (often a single bug)
    phrase_repeats = sum(1 for v in violations if v["check"] == "phrase_repeat")
    lsi_misses = sum(1 for v in violations if v["check"] == "lsi_presence")

    parts = []

    # First sentence: scale of the problem
    parts.append(
        f"{total} total violations across {distinct_checks} distinct check type(s)."
    )

    # Cluster detection
    if phrase_repeats >= 3:
        parts.append(
            f"{phrase_repeats} phrase_repeat violations suggest a clustered "
            f"phrasing pattern — usually a single phrase echoed across hero, "
            f"FAQ, and a why_igsce paragraph rather than independent slot bugs."
        )

    if lsi_misses >= 2:
        parts.append(
            f"{lsi_misses} lsi_presence misses suggest LSI terms were seeded "
            f"only into tutor_program cards, not into body paragraphs or FAQ "
            f"answers. Fix by rewriting a body sentence to include the term, "
            f"not by appending (see memory.md Entry #7)."
        )

    # Scope verdict
    if by_scope.get("CP-B", 0) > 0:
        parts.append(
            f"{by_scope['CP-B']} violation(s) scope to CP-B (structural — card_count "
            f"or lsi term selection). CP-B will need re-running before CP-C."
        )
    elif total <= 5:
        parts.append(
            "All violations scope to CP-C and look surgical. A targeted revise "
            "should clear them in one pass — full redo is not warranted."
        )
    else:
        parts.append(
            f"All {total} violations scope to CP-C but span enough slots that "
            f"a full redo of CP-C may be faster than surgical revise. "
            f"Operator's call."
        )

    return " ".join(parts)


# ---------------------------------------------------------------------------
# Recommended operator command
# ---------------------------------------------------------------------------

def recommend_command(violations: list[dict[str, str]]) -> tuple[str, str]:
    """Return (recommended_revise_text, alternative)."""
    by_slot = defaultdict(list)
    for v in violations:
        by_slot[v["slot"]].append(v)

    # Build a per-slot revise note
    slot_fixes = []
    for slot, viols in sorted(by_slot.items()):
        checks = ", ".join(v["check"] for v in viols)
        slot_fixes.append(f"{slot} ({checks})")

    revise_text = "revise: fix the following slots — " + "; ".join(slot_fixes)
    if len(violations) > 8:
        alternative = "redo  (CP-C full rewrite — recommended over revise at this volume)"
    else:
        alternative = "redo  (CP-C full rewrite — not recommended at this volume)"

    return revise_text, alternative


# ---------------------------------------------------------------------------
# Curation block emission
# ---------------------------------------------------------------------------

def emit_curation_block(
    yaml_path: str,
    exit_code: int,
    violations: list[dict[str, str]],
    attempt_number: int,
) -> None:
    by_check = Counter(v["check"] for v in violations)

    print("─── BUG CURATION CP-D ───")
    print(f"validator_command: py -3 tools/validate_page.py {yaml_path}")
    print(f"validator_exit_code: {exit_code}")
    print(f"total_violations: {len(violations)}")
    print(f"attempt_number: {attempt_number}")
    print()

    print("violations_by_check:")
    for check, count in sorted(by_check.items()):
        print(f"  {check}: {count}")
    print()

    print("violations_detail:")
    for v in violations:
        info = FIX_SCOPE_MAP.get(v["check"], {})
        scope = info.get("scope", "CP-C")
        cause = info.get("cause", "Unknown check — no mapping in curate_violations.py.")
        print(f"  - slot: {v['slot']}")
        print(f"    check: {v['check']}")
        print(f"    detail: {v['detail']}")
        print(f"    fix_scope: {scope}")
        print(f"    likely_root_cause: {cause}")
    print()

    print("root_cause_summary:")
    print(f"  {root_cause_summary(violations)}")
    print()

    revise, alternative = recommend_command(violations)
    print("recommended_operator_command:")
    print(f"  option_1: {revise}")
    print(f"  option_2: {alternative}")
    print()

    print("state_file_update:")
    print(f"  violations_at_last_validator_run: {sorted(set(v['check'] for v in violations))}")
    print("  last_checkpoint: CP-C (unchanged — CP-D did not advance)")
    print("  next_checkpoint: CP-D (will re-run after revise/redo + new CP-C output)")
    print()

    print("Awaiting operator command: revise: <note> | redo | inspect | abort")
    print("─── END BUG CURATION ───")


# ---------------------------------------------------------------------------
# State sidecar update (best-effort)
# ---------------------------------------------------------------------------

def update_state_sidecar(slug: str, checks: list[str]) -> None:
    """Call state_manager.py record-violations. Warn on failure but don't halt."""
    if not STATE_MANAGER.exists():
        print(
            f"WARN: {STATE_MANAGER} not found; skipping state sidecar update.",
            file=sys.stderr,
        )
        return

    try:
        result = subprocess.run(
            [sys.executable, str(STATE_MANAGER), "record-violations", slug, *checks],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            print(
                f"WARN: state_manager record-violations exited {result.returncode}: "
                f"{result.stderr.strip()}",
                file=sys.stderr,
            )
    except subprocess.SubprocessError as e:
        print(f"WARN: could not call state_manager: {e}", file=sys.stderr)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run validator, emit Bug Curation block at CP-D.",
    )
    parser.add_argument("yaml_path", help="Path to pages/<slug>.yaml")
    parser.add_argument(
        "--attempt", type=int, default=1,
        help="CP-D attempt number (1, 2, ...). Default 1.",
    )
    parser.add_argument(
        "--no-state-update", action="store_true",
        help="Skip the state_manager.py record-violations call.",
    )
    args = parser.parse_args(argv)

    yaml_path = Path(args.yaml_path)
    if not yaml_path.exists():
        print(f"ERROR: {yaml_path} not found", file=sys.stderr)
        return 2

    if not VALIDATOR.exists():
        print(f"ERROR: validator not found at {VALIDATOR}", file=sys.stderr)
        return 2

    # Run validator
    result = subprocess.run(
        [sys.executable, str(VALIDATOR), str(yaml_path)],
        capture_output=True, text=True,
    )

    if result.returncode == 0:
        # PASS — no curation needed
        print(result.stdout, end="")
        return 0

    if result.returncode == 2:
        # Validator could not run
        print(f"ERROR: validator could not run:\n{result.stderr}", file=sys.stderr)
        return 2

    # Exit 1 — violations present
    violations = parse_validator_output(result.stdout)
    if not violations:
        # Validator failed but emitted no parseable [FAIL] lines
        print("ERROR: validator exited 1 but emitted no parseable violations.",
              file=sys.stderr)
        print(result.stdout, file=sys.stderr)
        return 2

    slug = yaml_path.stem
    emit_curation_block(args.yaml_path, result.returncode, violations, args.attempt)

    # Persist violation checks into state sidecar
    if not args.no_state_update:
        unique_checks = sorted({v["check"] for v in violations})
        update_state_sidecar(slug, unique_checks)

    return 1


if __name__ == "__main__":
    sys.exit(main())
